FOUNDER SIGNAL · LinkedIn upload kit
Handle: linkedin.com/company/thefoundersignal

01-page-setup   logo (upload logo-400.png), banner (banner-A-1128x191.png; use the 4200x700 file if LinkedIn asks for the wide format), page copy, setup checklist
02-newsletter   newsletter logo + cover, issue 1 text and cover
03-posts-today  today's Signal cards (portrait = *.png, square = *-square.png) with CAPTIONS-5.md: caption, hashtags, pinned first comment per card
04-week1-posts  swap cards, thought-experiment cards, tool cards, three carousel PDFs (upload PDFs as document posts), and the week plan with every post's text
05-logos        brand marks in white and black for future cards
06-docs         concept, voice guide, engagement playbook, newsdesk routine, image requests
07-photos       people photos used, with credits.txt

Posting rules in one line: image or PDF attached, no links in the body, first comment with sources pinned within a minute, reply to every comment within 15 minutes for the first 90 minutes.
